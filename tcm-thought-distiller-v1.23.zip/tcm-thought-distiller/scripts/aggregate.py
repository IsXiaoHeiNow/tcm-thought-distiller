#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
aggregate.py —— 药对共现统计（tcm-thought-distiller 可选增强脚本）

用途：
  对「引文池 / 方剂清单」做药对（两两共现）与单药频次统计，
  为 L4c「药对库」的 B2 统计药对提供可复现的计数。

设计约束（对齐 skill 规则）：
  * 零第三方依赖，标准库即可运行（Python 3.8+）。
  * 输出为「纯计数」——不产出任何论断（不是〔AI 归纳〕）。
  * 写入产物时，计数结果必须加粗并带 〔AI 统计〕 与统计范围（T1/T2，自检 Q20）。
  * 默认排除使药（甘草/生姜/大枣等），避免高频药淹没信号（§2.10）。
  * 不输出剂量、不输出任何诊疗建议（红线 2）。

输入格式：
  text 模式（默认）：每行一条记录，药味以空格 / 顿号 / 逗号 / 分号 / 斜杠分隔。
  table 模式（--mode table）：解析 Markdown 表格，取第 --column 列（0 基）作为药味串。

用法示例：
  python aggregate.py 引文池.md --min-count 3 --exclude 甘草 生姜 大枣 -o 药对统计.md
  python aggregate.py 方剂与配伍.md --mode table --column 2 --scope "《XX》各兼类段 共 128 首方剂"
  python aggregate.py 引文池.md --lexicon 药名词表.txt --top 50
"""

import argparse
import re
import sys
from collections import Counter, defaultdict
from itertools import combinations

CJK = re.compile(r'^[\u4e00-\u9fff]+$')
SPLIT = re.compile(r'[、,，;；/|\s\-—·]+')

DEFAULT_EXCLUDE = ['甘草', '生姜', '大枣', '大枣肉', '炙甘草', '生甘草', '蜜']


# ---------------------------------------------------------------- 读取与分词

def read_records(path, mode, column, encoding):
    """返回 [(行号, 药味串), ...]"""
    with open(path, 'r', encoding=encoding) as f:
        lines = f.read().splitlines()

    records = []
    for idx, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#') or line.startswith('>'):
            continue

        if mode == 'table':
            if not line.startswith('|'):
                continue
            cells = [c.strip() for c in line.strip('|').split('|')]
            if all(re.fullmatch(r':?-{2,}:?', c) for c in cells if c):
                continue  # 分隔行
            if column >= len(cells):
                continue
            text = cells[column]
        else:
            text = line

        if text in ('', '—', '-', '药味', '原文药味（直引）'):
            continue
        if '—' == text or '—（本书无方剂）' in text:
            continue
        records.append((idx, text))
    return records


def tokenize(text, lexicon=None):
    """切出药名。lexicon 存在时用最长匹配扫描，否则按分隔符切分后过滤。"""
    if lexicon:
        found = []
        i = 0
        n = len(text)
        while i < n:
            matched = None
            for size in range(min(6, n - i), 0, -1):
                cand = text[i:i + size]
                if cand in lexicon:
                    matched = cand
                    break
            if matched:
                found.append(matched)
                i += len(matched)
            else:
                i += 1
        return found

    toks = []
    for t in SPLIT.split(text):
        t = t.strip()
        if not t:
            continue
        # 去掉常见后缀标注，如「人参（君）」「黄芪三钱」中的非汉字尾巴
        t = re.sub(r'[\d\.]+[钱两分厘克gGml斤枚片枚]*$', '', t)
        t = re.sub(r'[（(].*?[)）]', '', t).strip()
        if t and CJK.match(t) and 1 <= len(t) <= 4:
            toks.append(t)
    return toks


# ---------------------------------------------------------------- 统计

def aggregate(records, exclude, min_count, lexicon=None):
    pair_counter = Counter()
    herb_counter = Counter()
    pair_lines = defaultdict(set)
    n_records = 0

    for lineno, text in records:
        herbs = [h for h in tokenize(text, lexicon) if h not in exclude]
        uniq = sorted(set(herbs))
        if len(uniq) < 2:
            if uniq:
                herb_counter[uniq[0]] += 1
            continue
        n_records += 1
        for h in uniq:
            herb_counter[h] += 1
        for a, b in combinations(uniq, 2):
            pair_counter[(a, b)] += 1
            pair_lines[(a, b)].add(lineno)

    pairs = [(p, c) for p, c in pair_counter.items() if c >= min_count]
    pairs.sort(key=lambda x: (-x[1], x[0]))
    herbs = [(h, c) for h, c in herb_counter.items() if c >= min_count]
    herbs.sort(key=lambda x: (-x[1], x[0]))
    return pairs, herbs, n_records, pair_lines


# ---------------------------------------------------------------- 输出

def render(pairs, herbs, n_records, pair_lines, scope, min_count, exclude, top):
    scope_txt = scope if scope else '共 %d 条记录' % n_records
    out = []
    out.append('# 药对共现统计（可选增强 · 纯计数）\n')
    out.append('> **〔AI 统计·%s〕** 共现阈值 ≥%d；排除使药：%s\n'
               % (scope_txt, min_count, '、'.join(exclude) if exclude else '无'))
    out.append('> 本结果为**纯计数**，非〔AI 归纳〕；写入产物时须**加粗**并保留统计范围（T1/T2，自检 Q20）。\n')
    out.append('> 本表不构成任何诊疗建议、不作为医疗依据；不记录任何剂量。\n')

    out.append('\n## A · 药对共现（≥%d 次）\n' % min_count)
    if pairs:
        out.append('| 药组 | **共现次数** | 出现行号 | 证据类型 |')
        out.append('|---|---|---|---|')
        for (a, b), c in pairs[:top]:
            lines = ', '.join(str(x) for x in sorted(pair_lines[(a, b)])[:20])
            if len(pair_lines[(a, b)]) > 20:
                lines += ' …'
            out.append('| %s + %s | **〔AI 统计〕%d 次** | %s | `统计` |' % (a, b, c, lines))
    else:
        out.append('—（无满足阈值的药对）')

    out.append('\n## B · 单药频次（≥%d 次）\n' % min_count)
    if herbs:
        out.append('| 药名 | **出现次数** |')
        out.append('|---|---|')
        for h, c in herbs[:top]:
            out.append('| %s | **〔AI 统计〕%d 次** |' % (h, c))
    else:
        out.append('—（无满足阈值的单药）')

    out.append('\n## C · 统计口径卡（C1，须随产物存档）\n')
    out.append('| 口径项 | 取值 |')
    out.append('|---|---|')
    out.append('| 统计范围 | %s |' % scope_txt)
    out.append('| 共现阈值 | ≥%d |' % min_count)
    out.append('| 排除使药 | %s |' % ('、'.join(exclude) if exclude else '无'))
    out.append('| 计数单位 | 每条记录内去重后两两组合，每条记录计 1 次 |')
    out.append('| 是否含剂量 | 否（红线 2） |')

    out.append('\n---\n')
    out.append('> 免责声明：本文件为文献研究用的计数结果，**不构成任何诊疗建议、不作为医疗依据**。\n')
    return '\n'.join(out) + '\n'


def main(argv=None):
    ap = argparse.ArgumentParser(
        description='药对共现统计（tcm-thought-distiller 可选增强 · 纯计数）')
    ap.add_argument('input', help='输入文件（引文池 / 方剂清单，txt 或 md）')
    ap.add_argument('-o', '--output', help='输出文件；缺省输出到标准输出')
    ap.add_argument('--mode', choices=['text', 'table'], default='text',
                    help='text=每行一条记录（默认）；table=解析 Markdown 表格')
    ap.add_argument('--column', type=int, default=1,
                    help='table 模式下取第几列（0 基），默认 1')
    ap.add_argument('--min-count', type=int, default=3,
                    help='共现次数阈值，默认 3（与 L4c 默认一致）')
    ap.add_argument('--exclude', nargs='*', default=DEFAULT_EXCLUDE,
                    help='排除的使药列表；传空请用 --exclude （后不跟值）')
    ap.add_argument('--lexicon', help='药名词表文件（每行一个药名）；提供时按最长匹配切分')
    ap.add_argument('--scope', help='统计范围描述，写入 〔AI 统计·…〕 标记内')
    ap.add_argument('--top', type=int, default=200, help='最多输出多少行，默认 200')
    ap.add_argument('--encoding', default='utf-8', help='输入编码，默认 utf-8')
    args = ap.parse_args(argv)

    lexicon = None
    if args.lexicon:
        with open(args.lexicon, 'r', encoding=args.encoding) as f:
            lexicon = {ln.strip() for ln in f if ln.strip()}

    exclude = set(args.exclude or [])

    try:
        records = read_records(args.input, args.mode, args.column, args.encoding)
    except OSError as e:
        sys.stderr.write('读取失败：%s\n' % e)
        return 1

    if not records:
        sys.stderr.write('未解析到任何记录，请检查 --mode / --column 是否正确。\n')
        return 1

    pairs, herbs, n_records, pair_lines = aggregate(
        records, exclude, args.min_count, lexicon)
    text = render(pairs, herbs, n_records, pair_lines,
                  args.scope, args.min_count, sorted(exclude), args.top)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(text)
        sys.stderr.write('已写入 %s（记录 %d 条，药对 %d 组）\n'
                         % (args.output, n_records, len(pairs)))
    else:
        sys.stdout.write(text)
    return 0


if __name__ == '__main__':
    sys.exit(main())
